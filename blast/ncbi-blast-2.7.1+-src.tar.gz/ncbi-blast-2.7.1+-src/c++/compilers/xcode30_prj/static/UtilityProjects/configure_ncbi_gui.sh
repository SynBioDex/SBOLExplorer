#!/bin/sh
export PTB_FLAGS=
export PTB_PROJECT_REQ=scripts/projects/ncbi_gui.lst
$BUILD_TREE_ROOT/ptb.sh
